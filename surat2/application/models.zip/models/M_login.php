<?php
class M_login extends CI_Model{
	//cek nip dan password dosen
	// function auth_pegawai($username,$password){
	// 	$query=$this->db->query("SELECT * FROM pegawai WHERE nip='$username' AND password=MD5('$password') LIMIT 1");
	// 	return $query;
	// }

	function auth_verifikator($username,$password){
		$query=$this->db->query("SELECT * FROM verifikator WHERE nip='$username' AND password=MD5('$password') LIMIT 1");
		return $query;
	}
	function auth_admin($username,$password){
		$query=$this->db->query("SELECT * FROM admin WHERE nip='$username' AND password=MD5('$password') LIMIT 1");
		return $query;
	}

}

<?php 
	class M_surat_terverifikasi extends CI_model
	{

		public function getAllSuratTerverifikasi()
		{

			return $this->db->get('surat_terverifikasi')->result_array();
		}

		//untuk pagination da search jika belum login
		public function getSuratTerverifikasiAll($limit, $start, $keyword_cari, $tanggal_mulai, $tanggal_selesai)
		{
			if($keyword_cari){
				if(($tanggal_mulai)&&($tanggal_selesai)){
					return $this->db->query("SELECT * FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%' OR wakilpjb LIKE '%$keyword_cari%') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' LIMIT $start, $limit ") -> result_array();
				}else{
				return $this->db->query("SELECT * FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%'OR wakilpjb LIKE '%$keyword_cari%') LIMIT $start, $limit") -> result_array();
				}
			}else{
				$this->db->select('*');
	    		$this->db->from('surat_terverifikasi');
				if(!($keyword_cari)){
					if(($tanggal_mulai)&&($tanggal_selesai)){
						$this->db->where("tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'");
					}
				}
				$this->db->order_by('tanggal', 'DESC');
				$this->db->limit($limit, $start); 
    			$query = $this->db->get();
    			return $query->result_array();
			}
		}
		
		public function hitungBarisAll($keyword_cari = null, $tanggal_mulai = null, $tanggal_selesai = null){
			if($keyword_cari){
				if(($tanggal_mulai)&&($tanggal_selesai)){
					return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%'OR wakilpjb LIKE '%$keyword_cari%') AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' ") -> row_array();
				}else{
				return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%' OR wakilpjb LIKE '%$keyword_cari%')") -> row_array();
				}
			}elseif(!($keyword_cari) && ($tanggal_mulai)&&($tanggal_selesai)){
					return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' ") -> row_array();
			}else{
				return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi") -> row_array();
			}

		}
		//untuk pagination da search jika sudah login

		public function getSuratTerverifikasi($limit, $start, $verifikator, $keyword_cari, $tanggal_mulai, $tanggal_selesai)
		{
			if($keyword_cari){
				if(($tanggal_mulai)&&($tanggal_selesai)){
					return $this->db->query("SELECT * FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%'OR wakilpjb LIKE '%$keyword_cari%') AND verifikator = '$verifikator' AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' ") -> result_array();
				}else{
				return $this->db->query("SELECT * FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%'OR wakilpjb LIKE '%$keyword_cari%') AND verifikator = '$verifikator'") -> result_array();
				}
			}else{
				$this->db->select('*');
	    		$this->db->from('surat_terverifikasi');
				if(!($keyword_cari)){
					if(($tanggal_mulai)&&($tanggal_selesai)){
						
						$this->db->where("tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'");
					}
				}
				$this->db->where("verifikator", $verifikator);
				$this->db->order_by('tanggal', 'DESC');
				$this->db->limit($limit, $start); 
    			$query = $this->db->get();
    			return $query->result_array();
			}
		}
		
		public function hitungBaris($verifikator, $keyword_cari = null, $tanggal_mulai = null, $tanggal_selesai = null){
			if($keyword_cari){
				if(($tanggal_mulai)&&($tanggal_selesai)){
					return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%'OR wakilpjb LIKE '%$keyword_cari%') AND verifikator = '$verifikator' AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' ") -> row_array();
				}else{
				return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE (no_pendaftaran LIKE '%$keyword_cari%' OR nama_perusahaan LIKE '%$keyword_cari%' OR jenis_perusahaan LIKE '%$keyword_cari%' OR jenis_persetujuan LIKE '%$keyword_cari%' OR keterangan_persetujuan LIKE '%$keyword_cari%'OR wakilpjb LIKE '%$keyword_cari%') AND verifikator = '$verifikator'") -> row_array();
				}
			}elseif(!($keyword_cari) && ($tanggal_mulai)&&($tanggal_selesai)){
					return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE verifikator = '$verifikator' AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' ") -> row_array();
			}else{
				return $this->db->query("SELECT COUNT(*) as jumlah FROM surat_terverifikasi WHERE verifikator = '$verifikator'") -> row_array();
			}

		}

		public function getDataSurat($no_pendaftaran){
			return $this->db->get_where('surat_terverifikasi', array('no_pendaftaran' => $no_pendaftaran))->result_array();
		}

		public function getAtributSurat($no_pendaftaran){
			return $this->db->get_where('verifikasi', array('no_pendaftaran' => $no_pendaftaran))->result_array();
		}
	}

?>